package com.game.bagoh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BagohApplication {

	public static void main(String[] args) {
		SpringApplication.run(BagohApplication.class, args);
	}

}
