package com.game.bagoh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BagohApplicationTests {

	@Test
	void contextLoads() {
	}

}
